export function Footer() {
  return (
    <footer className="max-w-[1024px] mx-auto px-6 py-8 border-t border-neutral-100 flex flex-col md:flex-row justify-between items-center gap-6 mt-12">
      <p className="text-[11px] text-[#64748B] font-medium tracking-wide uppercase text-center md:text-left">
        © {new Date().getFullYear()} OneLynk Luxury Identity Studio • Built with precision
      </p>
      <div className="flex gap-6">
        {[
          { name: 'Instagram', url: 'https://www.instagram.com/onelynk.official/' },
          { name: 'LinkedIn', url: '#' },
          { name: 'Twitter', url: '#' }
        ].map((social) => (
          <a key={social.name} href={social.url} target="_blank" rel="noopener noreferrer" className="text-[11px] font-bold text-[#0A0A0A] uppercase tracking-wider hover:text-[#2563EB] cursor-pointer transition-colors">
            {social.name}
          </a>
        ))}
      </div>
    </footer>
  );
}
