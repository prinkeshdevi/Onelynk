import { motion } from 'motion/react';
import { ArrowRight, MessageCircle } from 'lucide-react';

export function ContactCTA() {
  return (
    <section className="px-6 py-24 max-w-[1024px] mx-auto">
      <div className="bg-[#0A0A0A] rounded-[32px] p-10 md:p-16 text-white relative overflow-hidden text-center">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-[#2563EB]/20 rounded-full blur-[80px]"></div>
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative z-10"
        >
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-6">
            Let's Build Your Identity.
          </h2>
          <p className="text-white/80 text-lg mx-auto mb-10 max-w-lg">
            Tailored exclusively for your business personality. No clutter, just impact.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button className="px-8 py-4 bg-white text-[#2563EB] font-bold rounded-2xl shadow-lg hover:bg-neutral-50 transition-colors">
              Book Consulting
            </button>
            <a href="https://wa.me/7385010471" target="_blank" rel="noopener noreferrer" className="px-8 py-4 bg-white/10 border border-white/20 text-white font-bold rounded-2xl hover:bg-white/20 transition-colors flex items-center justify-center gap-2">
              <MessageCircle className="w-5 h-5 text-green-400" />
              WhatsApp
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
