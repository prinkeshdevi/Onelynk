import { Hero } from './components/Hero';
import { WhyChange } from './components/WhyChange';
import { Demo } from './components/Demo';
import { WhatYouGet } from './components/WhatYouGet';
import { Process } from './components/Process';
import { Industries } from './components/Industries';
import { Portfolio } from './components/Portfolio';
import { WhyChooseUs } from './components/WhyChooseUs';
import { ClientReviews } from './components/ClientReviews';
import { FAQ } from './components/FAQ';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-[#2563EB] selection:text-white overflow-x-hidden">
      <header className="absolute top-0 inset-x-0 p-6 md:p-10 flex justify-between items-center z-50 max-w-7xl mx-auto mix-blend-difference">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center">
            <span className="text-[#050505] font-bold text-xl">L</span>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight uppercase leading-none text-white">OneLynk</h1>
            <span className="text-[10px] tracking-[0.2em] text-white/60 font-semibold uppercase">Studio</span>
          </div>
        </div>
        <div className="hidden sm:flex gap-8 items-center">
          <button className="px-6 py-3 bg-white text-[#050505] text-xs uppercase tracking-widest font-bold rounded-full hover:bg-neutral-200 transition-colors">
            Book Consultation
          </button>
        </div>
      </header>

      <main>
        <Hero />
        <WhyChange />
        <Demo />
        <WhatYouGet />
        <Process />
        <Industries />
        <Portfolio />
        <WhyChooseUs />
        <ClientReviews />
        <FAQ />
        <FinalCTA />
      </main>

      <Footer />
    </div>
  );
}
